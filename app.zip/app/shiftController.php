<?php
/**
 * Created by PhpStorm.
 * User: nita
 * Date: 6/10/2018
 * Time: 11:58 AM
 */

class shiftController{

    public function __construct()
    {

    }

    /**
     * @desc checks if two shifts of same employee are overlapping
     * @param json $schedule1
     * @param json $schedule2
     * @return boolean true - overlap /false- no overlap
     */
    public function isOverlapping($schedule1, $schedule2)
    {
        $schedule1Arr= json_decode($schedule1, true);
        $schedule2Arr= json_decode($schedule2, true);

        //if ID doesnot match, there is no overlapping
        if($schedule1Arr['Id']!= $schedule2Arr['Id'])
        {
            return false;
        }

        //if start or end time are exactly the same; there is a overlap
        if(($schedule1Arr['StartTime']=== $schedule2Arr['StartTime']) || ($schedule1Arr['EndTime']===$schedule2Arr['EndTime']))
        {
            return true;
        }


        //compare start date; check if two schedule are for same month/year/day;
        $schedule1StartDate= date('Y-m-d', $schedule1Arr['StartTime']);
        $schedule2StartDate= date('Y-m-d', $schedule2Arr['StartTime']);

        //if year, month and date is same for both schedule then compare start and end time of two schedule
        if($schedule1StartDate==$schedule2StartDate)
        {
            //if shift1 has not ended before shift2 starts or shift2 has not ended before shift1 starts; there is a overlap
            if(($schedule2Arr['StartTime']<=$schedule1Arr['EndTime']) || ($schedule1Arr['StartTime']<=$schedule2Arr['EndTime']))
            {
                return true;
            }
        }

        return false;

    }

}
